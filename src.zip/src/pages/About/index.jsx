import React from "react";

import "./styles.scss";

const About = () => (
  <div className="about-container">
    <h1 className="about">Trang About</h1>
  </div>
);
export default About;
