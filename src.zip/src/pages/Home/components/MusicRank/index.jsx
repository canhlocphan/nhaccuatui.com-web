// libs
import React from "react";

// others
import "./styles.scss";

const MusicRank = (props) => <div className="rank">{props.id}</div>;
export default MusicRank;
