// libs
import React from "react";

// others
import "./styles.scss";

const SongName = (props) => <div className="name-song">{props.songName}</div>;

export default SongName;
