// libs
import React from "react";

// others
import "./styles.scss";

const TimeVideo = (props) => <div className="view-time">{props.time}</div>;

export default TimeVideo;
