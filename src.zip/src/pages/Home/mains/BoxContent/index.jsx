import React from "react";

import "./styles.scss";

const BoxContent = () => (
  <div className="box-content">
    <div className="advertisement"></div>
  </div>
);

export default BoxContent;
