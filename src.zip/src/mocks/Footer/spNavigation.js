const spNavigation = [
  {
    id: "1",
    title: "Trợ giúp",
  },
  {
    id: "2",
    title: "Chính sách bảo mật",
  },
  {
    id: "3",
    title: "Sơ đồ",
  },
  {
    id: "4",
    title: "Chính sách SHTT",
  },
  {
    id: "5",
    title: "NCCI",
  },
  {
    id: "6",
    title: "Thỏa thuận sử dụng",
  },
  {
    id: "7",
    title: "Liên hệ quảng cáo",
  },
];

export default spNavigation;
