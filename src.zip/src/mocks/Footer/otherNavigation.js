const otherNavigation = [
  {
    id: "1",
    title: "Mobile App",
  },
  {
    id: "2",
    title: "Dịch vụ 3G",
  },
  {
    id: "3",
    title: "Mobile Web",
  },
  {
    id: "4",
    title: "NCT Corp",
  },
  {
    id: "5",
    title: "Smart TV",
  },
  {
    id: "6",
    title: "Tuyển dụng",
  },
  {
    id: "7",
    title: "Desktop",
  },
];

export default otherNavigation;
