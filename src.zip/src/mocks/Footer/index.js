import spNavigation from "./spNavigation";
import otherNavigation from "./otherNavigation";

const Footer = {
  spNavigation,
  otherNavigation,
};

export default Footer;
