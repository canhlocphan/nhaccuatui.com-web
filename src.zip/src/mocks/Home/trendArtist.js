const trendArtist = [
  {
    id: "1",
    image: "https://avatar-ex-swe.nixcdn.com/singer/avatar/2020/08/03/3/f/4/5/1596425768647_600.jpg",
    artist: "Bằng Cường",
  },
  {
    id: "2",
    image: "https://avatar-ex-swe.nixcdn.com/singer/avatar/2020/07/13/6/6/2/4/1594610566834_600.jpg",
    artist: "Gemini Band",
  },
  {
    id: "3",
    image: "https://avatar-ex-swe.nixcdn.com/singer/avatar/2021/05/12/7/d/c/b/1620802736418_600.jpg",
    artist: "Sơn Tùng MTP",
  },
  {
    id: "4",
    image: "https://avatar-ex-swe.nixcdn.com/singer/avatar/2020/09/22/5/3/5/d/1600744344048_600.jpg",
    artist: "Đình Dũng",
  },
  {
    id: "5",
    image: "https://avatar-ex-swe.nixcdn.com/singer/avatar/2020/05/20/5/f/e/3/1589944002038_600.jpg",
    artist: "Nguyên Hà",
  },
];

export default trendArtist;
