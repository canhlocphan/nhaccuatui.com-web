const karaoke = [
  {
    id: "1",
    large: "0",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2021/04/07/d/f/e/8/1617784916622_268.jpg",
    title: "Yêu Thầm (Karaoke)- Hoàng Yến Chibi, Tlinh, TDK",
    view: "20.392",
    time: "04:30",
  },
  {
    id: "2",
    large: "0",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2021/02/18/b/9/0/2/1613640971487_268.jpg",
    title: "Mình Đừng Quên Nhau (Karaoke)- Anh Tú Atus",
    view: "12.756",
    time: "04:19",
  },
  {
    id: "3",
    large: "0",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2021/02/04/b/f/9/1/1612423114203_268.jpg",
    title: "Right (Karaoke)- Niz",
    view: "7.578",
    time: "02:47",
  },
  {
    id: "4",
    large: "0",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2021/03/01/e/7/1/9/1614585118775_268.jpg",
    title: "Ép Duyên (Karaoke)- Yuni Boo, Nam Anh",
    view: "37.696",
    time: "07:58",
  },
];

export default karaoke;
