const albumHot = [
  {
    id: "1",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FalbumHot%2F1620204931258_300.jpg?alt=media&token=67498f77-1747-428c-aef1-aa2970553b85",
    title: "Mượn Gió Bẻ Măng - X2X",
    view: "83.922",
  },
  {
    id: "2",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FalbumHot%2F1619848955202_300.jpg?alt=media&token=95af4eea-e1f2-44e8-ac79-f5c7429d09f1",
    title: "Đừng Đùa Với Lửa (Thiên Thần Hộ Mệnh OST) - Lena",
    view: "197.720",
  },
  {
    id: "3",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FalbumHot%2F1619601720262_300.jpg?alt=media&token=fd7fddc4-1e79-4606-ba5d-08326bcb2a3d",
    title: "Hôm Nay Lạ Quá - BRay, Masew",
    view: "70.472",
  },
  {
    id: "4",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FalbumHot%2F1618839617642_300.jpg?alt=media&token=30a729e7-0eed-44d8-b37b-f1236a87680b",
    title: "Về Lại Bên Em - Tus, Quanium",
    view: "3.882",
  },
  {
    id: "5",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FalbumHot%2F1620058081401_300.jpg?alt=media&token=5d5f43f6-f6f1-4ddf-8557-92aa8cf4a301",
    title: "Nếu Gọi Là Anh Em - Thiên Dũng",
    view: "622",
  },
  {
    id: "6",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FalbumHot%2F1616742443204_300.jpg?alt=media&token=c1b7c750-12a7-411b-b2ca-3fbc1bfa6f59",
    title: "KG0516 - Karol G",
    view: "909",
  },
  {
    id: "7",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FalbumHot%2F1620373252571_300.jpg?alt=media&token=fc73232a-7536-488a-8d4e-72767d76a0e7",
    title: "Better Mistakes - Bebe Rexha",
    view: "115",
  },
  {
    id: "8",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FalbumHot%2F1616401589158_300.jpg?alt=media&token=27773cbc-9c77-4770-b3e1-ba80c53091d6",
    title: "Best Friend (feat. Doja Cat) [Remix EPT] - Saweetie",
    view: "72",
  },
  {
    id: "9",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FalbumHot%2F1613711206713_300.jpg?alt=media&token=5b626ae9-7298-41d5-b72a-0d4b803cd8fd",
    title: "The Book of Us : Negentropy - DAY 6",
    view: "2.436",
  },
  {
    id: "10",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FalbumHot%2F1618809105507_300.jpg?alt=media&token=7ae391ae-384a-411b-a596-4ce30a5fa806",
    title: "Positions (Deluxe) - Ariana Grande",
    view: "16.362",
  },
];

export default albumHot;
