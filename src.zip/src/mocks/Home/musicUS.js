const musicUS = [
  {
    id: "1",
    image: "https://avatar-ex-swe.nixcdn.com/song/2021/03/20/f/4/3/3/1616228602771.jpg",
    title: "Peaches - Justin Bieber, Daniel Caesar, Giveon",
  },
  {
    id: "2",
    image: "",
    title: "Mood - 24KGoldn, Iann Dior",
  },
  {
    id: "3",
    image: "",
    title: "34+35 - Ariana Grande",
  },
  {
    id: "4",
    image: "",
    title: "Kiss Me More - Doja Cat, SZA",
  },
  {
    id: "5",
    image: "",
    title: "Positions - Ariana Grande",
  },
  {
    id: "6",
    image: "",
    title: "Ice Cream - BlackPink, Selena Gomez",
  },
  {
    id: "7",
    image: "",
    title: "Mad At Disney - salem ilese",
  },
  {
    id: "8",
    image: "",
    title: "Montero (Call Me By Your Name) - Lil Nas X",
  },
  {
    id: "9",
    image: "",
    title: "Savage Love (Laxed ft Siren Beat) [bts Remix] - Jason Derulo, Jawsh 685, BTS (Bangtan Boys)",
  },
  {
    id: "10",
    image: "",
    title: "Drivers License - Olivia Rodrigo",
  },
];

export default musicUS;
