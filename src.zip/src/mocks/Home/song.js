const song = [
  {
    id: "1",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FbaiHat%2F1616731014799.png?alt=media&token=8e2d05d1-a010-47b8-b3b9-29e4022ed1c2",
    title: "Mộng Mơ - Masew, RedT",
    view: "778.414",
  },
  {
    id: "2",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FbaiHat%2F1609405407726.png?alt=media&token=61538268-9e0e-4779-8ab7-563a1ab4ab10",
    title: "Tình Đầu Là Dở Dang - BigP, TrungNguyen",
    view: "318.990",
  },
  {
    id: "3",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FbaiHat%2F1619939899154.png?alt=media&token=0970ffa6-376c-4e96-b52d-74d9481e923c",
    title: "Những Hạt Sương - Arrow, Olive",
    view: "20.612",
  },
  {
    id: "4",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FbaiHat%2F1620098167064.png?alt=media&token=0b4a3386-1725-4f16-bc96-45ba0401730c",
    title: "Without You (Miley Cyrus Remix) - The Kid LAROI, Miley Cyrus",
    view: "9.119",
  },
  {
    id: "5",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FbaiHat%2F1619752608643.png?alt=media&token=fb1703c0-67b2-4ea5-8b4d-c1c57e2c78ac",
    title: "In The Morning - ITZY",
    view: "127.682",
  },
  {
    id: "6",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FbaiHat%2F1620640694359.png?alt=media&token=b86bf5c5-deca-4d82-9540-34d99e3397d8",
    title: "Mẩy Thật Mẩy - BigDaddy, 1989s Entertainment",
    view: "37.332",
  },
  {
    id: "7",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FbaiHat%2F1620552521567.png?alt=media&token=e76fcf1e-1a1e-4790-a46c-6f1965cabf8e",
    title: "Cho Ngày Không Còn Nhau - T.R.I",
    view: "8.552",
  },
  {
    id: "8",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FbaiHat%2F1618839617642.png?alt=media&token=52c0dc88-fd3d-470c-bf4e-83b303709a2c",
    title: "Về Lại Bên Em - Tus, Quanium",
    view: "4.812",
  },
  {
    id: "9",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FbaiHat%2F1620707269568.png?alt=media&token=40132acd-9191-41f0-b2e4-1f572e0ab2d9",
    title: "Sailing - Ahn Ye Eun",
    view: "8.610",
  },
  {
    id: "10",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FbaiHat%2F1612516037863.png?alt=media&token=f5cc9e61-c3e4-4531-a70c-dbe387f83319",
    title: "Airplane - Stray Kids",
    view: "691",
  },
  {
    id: "11",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FbaiHat%2F1607940267802.png?alt=media&token=5eeb774b-85fa-4b6e-82ce-54ccb51044bf",
    title: "Best Friend (Feat. Doja Cat) - Saweetie",
    view: "6.179",
  },
  {
    id: "12",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FbaiHat%2F1620460673811.png?alt=media&token=32597c4f-fea8-4804-bc56-9c154c199b7e",
    title: "Phũ Phàng - Trương Ngôn",
    view: "3.607",
  },
];

export default song;
