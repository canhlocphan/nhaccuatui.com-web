// mocks
import bXHMVVN from "./bXHMVVN";
import bXHMVUS from "./bXHMVUS";
import bXHMVK from "./bXHMVK";

const chartMV = {
  bXHMVVN,
  bXHMVUS,
  bXHMVK,
};

export default chartMV;
