const musicVietNam = [
  {
    id: "1",
    image: "https://avatar-ex-swe.nixcdn.com/song/2021/04/29/9/1/f/8/1619691182261.jpg",
    title: "Muộn Rồi Mà Sao Còn - Sơn Tùng MTP",
  },
  {
    id: "2",
    image: "",
    title: "Sài Gòn Đau Lòng Quá - Hứa Kim Tuyền, Hoàng Duyên",
  },
  {
    id: "3",
    image: "",
    title: "Câu Hẹn Câu Thề - Đình Dũng, ACV",
  },
  {
    id: "4",
    image: "",
    title: "Nàng Thơ - Hoàng Dũng",
  },
  {
    id: "5",
    image: "",
    title: "Laylalay - Jack - J97",
  },
  {
    id: "6",
    image: "",
    title: "Răng Khôn - Phí Phương Anh, RIN9",
  },
  {
    id: "7",
    image: "",
    title: "Tình Bạn Diệu Kỳ - Ricky Star, Lăng LD, AMee",
  },
  {
    id: "8",
    image: "",
    title: "Vách Ngọc Ngà - Anh Rồng",
  },
  {
    id: "9",
    image: "",
    title: "Phải Chăng Em Đã Yêu? - Juky San, RedT",
  },
  {
    id: "10",
    image: "",
    title: "Tháng Mấy Em Nhớ Anh? - Hà Anh Tuấn",
  },
];

export default musicVietNam;
