const bXHMVVN = [
  {
    id: "1",
    large: "1",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2021/04/27/f/3/8/f/1619516817597_536.jpg",
    title: "Đừng Hẹn Kiếp Sau - Đình Dũng, ACV",
  },
  {
    id: "2",
    large: "0",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2021/04/12/e/3/c/3/1618223700298.jpg",
    title: "Laylalay - Jack",
  },
  {
    id: "3",
    large: "0",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2021/04/23/b/5/f/2/1619159050578.jpg",
    title: "Điều Dang Dở Ngọt Ngào (Hướng Dương Ngược Nắng P2 OST) - Hương Ly",
  },
  {
    id: "4",
    large: "0",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2021/04/18/9/2/f/2/1618750416503.jpg",
    title: "Thiên Hạ Hữu Tình Nhân - Đan Trường, Juky San",
  },
  {
    id: "5",
    large: "0",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2021/04/07/d/f/e/8/1617784916622.jpg",
    title: "Yêu Thầm - Hoàng Yến Chibi, Tlinh, TDK",
  },
];

export default bXHMVVN;
