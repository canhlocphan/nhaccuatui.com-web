const listeningWhatToday = [
  {
    id: "1",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FngheGi%2F1612496337944_300.jpg?alt=media&token=9c10cb5b-2573-4d50-afc8-faffd1eaada3",
    title: "Ballad Gây Thương Nhớ Nhất - V.A",
    view: "324.417",
  },
  {
    id: "2",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FngheGi%2F1620653755451_300.jpg?alt=media&token=022b8339-88e0-457c-ae55-3907f97a7c0f",
    title: "Do You Wanna Đu - V.A",
    view: "4.926",
  },
  {
    id: "3",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FngheGi%2F1620383125006_300.jpg?alt=media&token=f7c853e1-29a5-4dd7-9e93-b921adf33a00",
    title: "EDM Mới Nhất - V.A",
    view: "7.596",
  },
  {
    id: "4",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FngheGi%2F1620356405109_300.jpg?alt=media&token=ae066b8a-2c7e-4e64-b873-5ef603f6b57d",
    title: "Nhạc Việt Hôm Nay Nghe Gì - V.A",
    view: "141.8626",
  },
  {
    id: "5",
    image:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2FngheGi%2F1620100988545_300.jpg?alt=media&token=f08a1963-ba47-448c-8a04-3d1ac6289257",
    title: "Top 100 Nhạc Trẻ Hay Nhất - V.A",
    view: "19.95.9815",
  },
];

export default listeningWhatToday;
