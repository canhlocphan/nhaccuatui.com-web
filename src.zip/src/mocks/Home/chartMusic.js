// mocks
import musicVietNam from "./musicVietNam";
import musicUS from "./musicUS";
import musicK from "./musicK";

const chartMusic = {
  musicVietNam,
  musicUS,
  musicK,
};

export default chartMusic;
