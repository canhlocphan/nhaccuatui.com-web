const bXHMVK = [
  {
    id: "1",
    large: "1",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2021/05/03/3/0/3/9/1620011613538_536.jpg",
    title: "In The Morning - ITZY",
  },
  {
    id: "2",
    large: "0",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2021/03/12/e/f/9/3/1615527333332.jpg",
    title: "On The Ground - ROSÉ (BlackPink)",
  },
  {
    id: "3",
    large: "0",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2021/04/05/2/9/7/1/1617586430782.jpg",
    title: "Gone - ROSÉ (BlackPink)",
  },
  {
    id: "4",
    large: "0",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2018/06/15/5/2/9/e/1529053957669.jpg",
    title: "DDu-Du DDu-Du - BlackPink",
  },
  {
    id: "5",
    large: "0",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2019/04/04/0/4/1/c/1554391317489.jpg",
    title: "Kill This Love - BlackPink",
  },
];

export default bXHMVK;
