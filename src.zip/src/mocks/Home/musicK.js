const musicK = [
  {
    id: "1",
    image: "https://avatar-ex-swe.nixcdn.com/song/2021/04/30/3/2/c/c/1619752608643.jpg",
    title: "In The Morning - ITZY",
  },
  {
    id: "2",
    image: "",
    title: "Gone - ROSÉ",
  },
  {
    id: "3",
    image: "",
    title: "On The Ground - ROSÉ",
  },
  {
    id: "4",
    image: "",
    title: "How You Like That - BlackPink",
  },
  {
    id: "5",
    image: "",
    title: "Lovesick Girls - BlackPink",
  },
  {
    id: "6",
    image: "",
    title: "Still With You - Jung Kook (BTS)",
  },
  {
    id: "7",
    image: "",
    title: "Celebrity - IU",
  },
  {
    id: "8",
    image: "",
    title: "I Can't Stop Me - TWICE",
  },
  {
    id: "9",
    image: "",
    title: "After School - Weeekly",
  },
  {
    id: "10",
    image: "",
    title: "Bet You Wanna - BlackPink, Cardi B",
  },
];

export default musicK;
