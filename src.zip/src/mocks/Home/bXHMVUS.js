const bXHMVUS = [
  {
    id: "1",
    large: "1",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2021/03/05/6/9/3/2/1614931483997_536.jpg",
    title: "Leave The Door Open - Bruno Mars, Anderson Paak, Silk Sonic",
  },
  {
    id: "2",
    large: "0",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2020/10/14/d/f/6/e/1602658897241.jpg",
    title: "At My Worst - Pink Sweat$",
  },
  {
    id: "3",
    large: "0",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2021/04/15/6/6/8/4/1618499388651.jpg",
    title: "Lazybaby - Dove Cameron",
  },
  {
    id: "4",
    large: "0",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2021/05/09/2/a/c/a/1620575578219.jpg",
    title: "Choker - Twenty One Pilots",
  },
  {
    id: "5",
    large: "0",
    image: "https://avatar-ex-swe.nixcdn.com/mv/2021/03/19/d/9/1/e/1616140185901.jpg",
    title: "Peaches - Justin Bieber, Daniel Caesar, Giveon",
  },
];

export default bXHMVUS;
