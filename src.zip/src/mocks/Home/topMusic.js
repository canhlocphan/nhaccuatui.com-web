const topMusic = [
  {
    id: "1",
    image: "https://avatar-ex-swe.nixcdn.com/topic/thumb/2020/06/17/7/d/8/9/1592361737432_org.jpg",
    title: "Mưa",
  },
  {
    id: "2",
    image: "https://avatar-ex-swe.nixcdn.com/topic/thumb/2020/09/25/7/3/f/7/1601005758702_org.jpg",
    title: "Giải thưởng âm nhạc",
  },
  {
    id: "3",
    image: "https://avatar-ex-swe.nixcdn.com/topic/thumb/2020/06/22/9/7/b/e/1592809801965_org.jpg",
    title: "Hot K-POP",
  },
  {
    id: "4",
    image: "https://avatar-ex-swe.nixcdn.com/topic/thumb/2021/01/21/b/2/8/a/1611215799487_org.jpg",
    title: "JYP - Nation",
  },
  {
    id: "5",
    image: "https://avatar-ex-swe.nixcdn.com/topic/thumb/2020/06/15/b/1/e/6/1592202213961_org.jpg",
    title: "Summer",
  },
];

export default topMusic;
