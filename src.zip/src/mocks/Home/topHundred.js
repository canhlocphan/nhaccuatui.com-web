const topHundred = [
  {
    id: "1",
    image: "https://avatar-ex-swe.nixcdn.com/playlist/2020/09/16/e/1/f/f/1600239245257.jpg",
    title: "Top 100 Pop USUK Hay Nhất",
  },
  {
    id: "2",
    image: "https://avatar-ex-swe.nixcdn.com/playlist/2020/09/16/e/1/f/f/1600250876973.jpg",
    title: "Top 100 Nhạc Không Lời Hay Nhất",
  },
  {
    id: "3",
    image: "https://avatar-ex-swe.nixcdn.com/playlist/2020/09/29/f/9/f/7/1601348348354.jpg",
    title: "Top 100 Nhạc Trịnh Hay Nhất",
  },
  {
    id: "4",
    image: "https://avatar-ex-swe.nixcdn.com/playlist/2020/09/16/e/1/f/f/1600250721042.jpg",
    title: "Top 100 Nhạc Country Hay Nhất",
  },
  {
    id: "5",
    image: "https://avatar-ex-swe.nixcdn.com/playlist/2020/09/16/e/1/f/f/1600239245257.jpg",
    title: "Top 100 Electronica/Dance Hay Nhất",
  },
];

export default topHundred;
