const slideDefaultImage = [
  {
    id: "1",
    small:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2F1620641097840_145.jpg?alt=media&token=79ef9b62-fac0-404e-8488-42b2dbaf2d5f",
    large:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2F1620641097840_org.jpg?alt=media&token=628238ce-23c1-47a1-93bc-b8532672e0a3",
    title: "Mẩy Thật Đấy - BigDaddy",
  },
  {
    id: "2",
    small:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2F1620633191534_145.jpg?alt=media&token=b311466a-ad6c-4543-97f9-a290e4b0c5cc",
    large:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2F1620633191534_org.jpg?alt=media&token=fbd823e6-f0a0-4fce-9b37-71dd3caf5682",
    title: "Cho Ngày Không Còn Nhau - T.R.I",
  },
  {
    id: "3",
    small:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2F1620632958206_145.jpg?alt=media&token=f43e8c22-4018-4fc3-be3d-767e8ce7957a",
    large:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2F1620632958206_org.jpg?alt=media&token=7e32ec57-741b-44a8-96dd-c38bceaaaf09",
    title: "Đã Từng Là Tất Cả - Gemini Band",
  },
  {
    id: "4",
    small:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2F1620630252759_145.jpg?alt=media&token=87910294-f005-405a-9c99-5c872cb29586",
    large:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2F1620630252759_org.jpg?alt=media&token=a5016700-388d-45a7-8e13-8840a6136158",
    title: "Album Hai Ta Đã Khác - DC Tâm",
  },
  {
    id: "5",
    small:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2F1620359349369_145.jpg?alt=media&token=becabbbd-a895-4636-9b7b-f150f47863df",
    large:
      "https://firebasestorage.googleapis.com/v0/b/main-page-b5c0f.appspot.com/o/nhaccuatui.com%2F1620359349369_org.jpg?alt=media&token=35bf6fef-30c2-4aba-8da6-ea1313f57332",
    title: "V-POP Nhạc Mới Mỗi Ngày",
  },
];

export default slideDefaultImage;
