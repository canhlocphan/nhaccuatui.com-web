const cooperationList = [
  {
    id: "1",
    image: "https://stc-id.nixcdn.com/v11/images/footer/1-new.png",
  },
  {
    id: "2",
    image: "https://stc-id.nixcdn.com/v11/images/footer/2-new.png",
  },
  {
    id: "3",
    image: "https://stc-id.nixcdn.com/v11/images/footer/17.png",
  },
  {
    id: "4",
    image: "https://stc-id.nixcdn.com/v11/images/footer/13.png",
  },
  {
    id: "5",
    image: "https://stc-id.nixcdn.com/v11/images/footer/12.png",
  },
  {
    id: "6",
    image: "https://stc-id.nixcdn.com/v11/images/footer/14.png",
  },
  {
    id: "7",
    image: "https://stc-id.nixcdn.com/v11/images/footer/15.png",
  },
  {
    id: "8",
    image: "https://stc-id.nixcdn.com/v11/images/footer/3-new.png",
  },
  {
    id: "9",
    image: "https://stc-id.nixcdn.com/v11/images/footer/10.png",
  },
  {
    id: "10",
    image: "https://stc-id.nixcdn.com/v11/images/footer/14.png",
  },
  {
    id: "11",
    image: "https://stc-id.nixcdn.com/v11/images/footer/1-new.png",
  },
  {
    id: "12",
    image: "https://stc-id.nixcdn.com/v11/images/footer/2-new.png",
  },
  {
    id: "13",
    image: "https://stc-id.nixcdn.com/v11/images/footer/17.png",
  },
  {
    id: "14",
    image: "https://stc-id.nixcdn.com/v11/images/footer/13.png",
  },
  {
    id: "19",
    image: "https://stc-id.nixcdn.com/v11/images/footer/12.png",
  },
];

export default cooperationList;
