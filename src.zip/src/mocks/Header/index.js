import HeaderList from "./HeaderList";
import cooperationList from "./cooperationList";

const Header = {
  HeaderList,
  cooperationList,
};

export default Header;
