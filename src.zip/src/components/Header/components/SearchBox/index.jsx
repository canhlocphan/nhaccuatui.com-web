// libs
import React from "react";

// others
import "./styles.scss";

const SearchBox = () => (
  <li className="search">
    <form className="form-search">
      <input placeholder="Tìm bài hát, video, playlist, ca sĩ"></input>
    </form>
  </li>
);
export default SearchBox;
