// libs
import React from "react";
// others
import "./styles.scss";

const Logo = () => <li className="logo"></li>;
export default Logo;
