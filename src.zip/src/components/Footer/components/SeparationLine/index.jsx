// libs
import React from "react";

// others
import "./styles.scss";

const SeparationLine = () => <div className="separation-line"></div>;

export default SeparationLine;
