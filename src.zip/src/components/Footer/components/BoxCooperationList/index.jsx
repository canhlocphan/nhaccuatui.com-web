// libs
import React, { useEffect, useState } from "react";
// components
import CooperationList from "../CooperationList";
import ButtonPreCarousel from "../ButtonPreCarousel";
import ButtonNextCarousel from "../ButtonNextCarousel";
// mocks
import Header from "../../../../mocks/Header";
// others
import "./styles.scss";

const BoxCooperationList = () => {
  const [startId, setStartId] = useState(0);
  const [stopId, setStopId] = useState(6);
  useEffect(() => {
    const time = setInterval(() => {
      if (startId === 9) {
        setStartId(0);
        setStopId(6);
      } else {
        setStartId(startId + 1);
        setStopId(stopId + 1);
      }
    }, 3000);
    return () => clearInterval(time);
  });
  return (
    <div className="footer-cooperation-list-wrapper">
      <CooperationList
        header={Header.cooperationList}
        startId={startId}
        stopId={stopId}
        setStartId={setStartId}
        setStopId={setStopId}
      ></CooperationList>
      <ButtonPreCarousel
        startId={startId}
        setStartId={setStartId}
        stopId={stopId}
        setStopId={setStopId}
      ></ButtonPreCarousel>
      <ButtonNextCarousel
        startId={startId}
        setStartId={setStartId}
        stopId={stopId}
        setStopId={setStopId}
      ></ButtonNextCarousel>
    </div>
  );
};

export default BoxCooperationList;
