// libs
import React from "react";

// others
import "./styles.scss";

const FooterTitleCooperation = (props) => <div className="footer-title-cooperation">{props.children}</div>;

export default FooterTitleCooperation;
